/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author jdani
 */
public class ModeloTabla extends AbstractTableModel{
    public ArrayList<ArrayList<String>> data;
    public ArrayList<String> encabezados;
    
    ModeloTabla(){
        data = new ArrayList();
        encabezados = new ArrayList();
    
    }
    
    public void agregarFila(ArrayList d){
        data.add(d);
    }
    
     public void ponerEncabezados(ArrayList d){
        encabezados=d;
    }
    
    public int getColumnCount() {
        return data.get(0).size();
    }
    
    public int getRowCount() {
        return data.size();
    }
 
    public String getColumnName(int col) {
        return encabezados.get(col);
    }
    
    public Object getValueAt(int row, int col) {
        return data.get(row).get(col);
    }
    
    public Class getColumnClass(int c) {
        return new String().getClass();
    }
    
    public boolean isCellEditable(int row, int col) {
        return true;
    }
    
}



