/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author ricardoi
 */
public class DatosTabla1 extends AbstractTableModel{
    
    public ArrayList<ArrayList<String>> data;
    public List<String> encabezados;
    
    DatosTabla1(ArrayList d,List<String> e){
        data = d;
        encabezados = e;
    }
    
    public int getColumnCount() {
        return data.get(0).size();
    }

    public int getRowCount() {
        return data.size();
    }

    public String getColumnName(int col) {
        return encabezados.get(col);
    }

    public Object getValueAt(int row, int col) {
        return data.get(row).get(col);
    }

    public Class getColumnClass(int c) {
        return getValueAt(0, c).getClass();
    }

    /*
     * Don't need to implement this method unless your table's
     * editable.
     */
    public boolean isCellEditable(int row, int col) {
        return false;
    }

    
    
    
}
